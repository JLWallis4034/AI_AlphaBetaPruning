// Include iostream and algorithm to allow for printing and use of the max() and min() functions.
#include <iostream>
#include <algorithm>
using namespace std;

// Create two variables with very high positive and negative values.
const int maximum = INT_MAX;
const int minimum = INT_MIN;

// A bool called AlphaBeta is created to facilitate alpha-beta pruning. If beta is less than or equal
// to alpha (the right node is less than or equal to the left node), it returns true; else, false is returned.
bool AlphaBeta(int alpha, int beta)
{
	if (beta <= alpha)
		return true;
	else
		return false;
}

int MiniMax(int index, int depth, int movesList[], int a_val, int b_val, bool isMaxPlayer)
{
	// If the program has examined all values within the tree, the program has finished.
	if (depth == 4)
	{
		return movesList[index];
	}

	// modIndex is created to simplify the recursion later.
	int modIndex = index * 2;

	// Using depth-first search, each player chooses either the highest or lowest value available, depending on whose turn it is.
	if (isMaxPlayer)
	{
		// If the player going for maximum score is active, the best value bVal is set to the minimum value.
		int bVal = minimum;

		// The for loop recurs to check both sides of each node.
		for (int i = 0; i < 2; i++)
		{
			int val = MiniMax(modIndex + i, depth + 1, movesList, a_val, b_val, false);

			// The max function is called twice. The first call determines the highest of two child nodes connected
			// to a parent node and sets the result to bVal; the second call determines the highest of the alpha value
			// and best value and sets the result to a_val.
			bVal = max(bVal, val);
			a_val = max(a_val, bVal);

			// Alpha-beta pruning occurs here. If AlphaBeta is true, the function stops searching the current branch,
			// as anything beyond the value is unneeded.
			if (AlphaBeta(a_val, b_val))
			{
				break;
			}
		}
		return bVal;
	}
	
	else
	{
		// If the player going for minimum score is active, the best value bVal is set to the maximum value.
		int bVal = maximum;

		// The for loop recurs to check both sides of each node.
		for (int i = 0; i < 2; i++)
		{
			// The min function is called twice. The first call determines the lowest of two child nodes connected
			// to a parent node and sets the result to bVal; the second call determines the lowest of the beta value
			// and best value and sets the result to b_val.
			int val = MiniMax(modIndex + i, depth + 1, movesList, a_val, b_val, true);
			bVal = min(bVal, val);
			b_val = min(b_val, bVal);

			// Alpha-beta pruning occurs here, as in the case of the player going for the max score.
			if (AlphaBeta(a_val, b_val))
			{
				break;
			}
		}
		return bVal;
	}
}

int main()
{
	int moves[16] = {9, 2, -3, 4, -9, 7, 6, 2, 12, 4, 5, 8, -7, 3, -4, -2};

	// An integer oVal is created to store the result of the minimax/alpha-beta pruning function.
	int oVal = MiniMax(0, 0, moves, minimum, maximum, true);
	cout << "Optimal value: " << oVal;
	return 0;
}